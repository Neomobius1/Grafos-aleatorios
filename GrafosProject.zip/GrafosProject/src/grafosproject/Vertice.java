/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafosproject;

/**
 *
 * @author Tania
 */
public class Vertice {
    
    //-----definición de variables para vertices---
    private String vname;
    private Integer indice;
    private Integer numAristas;
    private double x, y;

    //-------Definición de constructores de vertices-------
    public Vertice(String vname) {
        this.vname = vname;
        this.numAristas = 0;
    }
    
    public Vertice(int vname) {
        this.indice = vname;
        this.vname = "no" + vname;
        this.numAristas = 0;
    }

    public Vertice(int vname, double x, double y) {
        this.indice = vname;
        this.vname = "no" + vname;
        this.x = x;
        this.y = y;
    }

    public double getX() { return x; }  // para metodo simple
    public double getY() { return y; }
   //-----------------------------------------------------------
    public String getName() { return vname; }
    public Integer getNumEdges() { return numAristas; }
    public Integer getIndex() { return indice; }

   
}
