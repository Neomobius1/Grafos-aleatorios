/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package grafosproject;
import java.util.*;
import java.io.FileNotFoundException;

/**
 *
 * @author Tania
 */

public class Grafo {

    private Vertice[] vertice;
    private final int nVertices;
    private int nAristas;
    private static Formatter salida;
    private HashMap<Vertice, HashSet<Vertice>> grafo;
    
    
    
   /*Construc Para los grafos*/
    
    public Grafo(int numVertices) {
        this.nVertices = numVertices;
        this.vertice = new Vertice[numVertices];
        this.grafo = new HashMap<>();
        for (int i = 0; i < numVertices; i++) {
            Vertice n = new Vertice(i);
            this.vertice[i] = n;
            this.grafo.put(n, new HashSet<>());
        }
    }
    
    
    

    public Grafo(int numVertices, String modelo) {
        this.grafo = new HashMap<>();
        this.nVertices = numVertices;
        this.vertice = new Vertice[numVertices];

        Random coordX = new Random();
        Random coordY = new Random();

        if (modelo.equals("geograficosimple")) {
            for (int i = 0; i < numVertices; i++) {
                Vertice n = new Vertice(i, coordX.nextDouble(), coordY.nextDouble());

                this.vertice[i] = n;
                this.grafo.put(n, new HashSet<>());
            }
        }
    }


    /*Retorno de no. de aristas, de un vertice de tipo i*/
    private int gradoVertice(int i) {
        Vertice n1 = this.getNode(i);
        return this.grafo.get(n1).size();
    }

    
    //Conexión de vertices
    private void conectarVertices(int i, int j) {
        Vertice n1 = this.getNode(i);
        Vertice n2 = this.getNode(j);
       /*Para obtener los aristas en los index i y j*/
        HashSet<Vertice> aristas1 = this.getEdges(i);
        HashSet<Vertice> aristas2 = this.getEdges(j);
        /*Conjunción de vertices*/
        aristas1.add(n2);
        aristas2.add(n1);
        this.nAristas +=1;
    }

    /*Verificación de conexión (para las aristas)*/
    private Boolean existeConexion(int i, int j) {
         /*Para obtener los vértices de los index i y j*/
        Vertice n1 = this.getNode(i);
        Vertice n2 = this.getNode(j);
        /*Para las  aristas de cada vértice*/
        HashSet<Vertice> aristas1 = this.getEdges(i);
        HashSet<Vertice> aristas2 = this.getEdges(j);
        
        if  (aristas1.contains(n2) || aristas2.contains(n1)){
        return true;
        }
        
        else {
        
        return false;}
         
    }
    
    
    //Distancia entre 2 vertices , mod geografico
    private double distanciaVertices(Vertice n1, Vertice n2) {
        return Math.sqrt(Math.pow((n1.getX() - n2.getX()), 2) + Math.pow((n1.getY() - n2.getY()), 2));
    }

    private int getNumNodes() {return nVertices;}

    private int getNumEdges() {return nAristas;}

    private Vertice getNode(int i) {return this.vertice[i];}

    private HashSet<Vertice> getEdges(int i) {
        Vertice n = this.getNode(i);
        return this.grafo.get(n);
    }

    

    /*String para el grafo*/
    public String toString() {
        StringBuilder salida;

        salida = new StringBuilder("graph {\n");
        for (int i = 0; i < this.getNumNodes(); i++) {
            salida.append(this.getNode(i).getName()).append(";\n");
        }

        for (int i = 0; i < this.getNumNodes(); i++) {
            HashSet<Vertice> aristas = this.getEdges(i);
            for (Vertice n : aristas) {
                salida.append(this.getNode(i).getName()).append(" -- ").append(n.getName()).append(";\n");
            }
        }

        salida.append("}\n");

        return salida.toString();
    }
    
    
   /*-----------------------------------------MODELOS----------------------------------- */
    //modelo Erdos Renyi
    
    public void modeloER(int numAristas) {
        Random randomNum1 = new Random();
        Random randomNum2 = new Random();
        while (this.getNumEdges() < numAristas) {
            int num1 = randomNum1.nextInt(this.getNumNodes());
            int num2 = randomNum2.nextInt(this.getNumNodes());
            if (num1 != num2) {
                if (!existeConexion(num1, num2)) {
                    conectarVertices(num1, num2);
                }
            }
        }
    }

    //Modelo Gilbert
    public void modeloGilbert(double probabilidad) {
        Random randomNum = new Random();

        for (int i = 0; i < this.getNumNodes(); i++) {
            for (int j = 0; j <this.getNumNodes(); j++) {
                if ((i != j) && (randomNum.nextDouble() <= probabilidad)) {
                    if (!existeConexion(i, j)) {
                        conectarVertices(i, j);
                    }
                }
            }
        }
    }

    //modelo Geoespacial simple
    public void modeloGeoSimple(double r) {
    for(int i = 0; i < this.getNumNodes(); i++) {
      for(int j = i + 1; j < this.getNumNodes(); j++) {
        double distancia = distanciaVertices(this.getNode(i), this.getNode(j));
        if (distancia <= r) {
            conectarVertices(i, j);
        }
      }
    }
   }
   
    
    
    //modelo Barabasi Albert
    public void modeloBA(int d) {
        Random volado = new Random();
        
        double p;     
        for (int i = 0; i < this.getNumNodes();i++) {
            for (int j = (i+1); j < this.getNumNodes(); j++) {
                
                p = 1 - (gradoVertice(i)/d);

                if (0 < p) {
                    if ((!existeConexion(i,j))){
                        conectarVertices(i, j);
                    }
                }
            }

            if (gradoVertice(i) >= d) { i++; }
        }
    }

    /*-----------------------------------------FIN MODELOS----------------------------------- */
    
   /*Metodo para crear el archivo .gv*/
    public void writeDoc(String nombre) {
        try {
            salida = new Formatter(nombre);

        } catch (SecurityException securityException) {
            System.err.println("No se tienen permisos de escritora");
            System.exit(1);

        } catch (FileNotFoundException fileNotFoundException) {
            System.err.println("ERROR... NO SE PUDO ABRIR EL ARCHIVO");
            System.exit(1);
        }

        try {
            salida.format("%s",this);

        } catch (FormatterClosedException formatterClosedException) {
            System.err.println("ERROR... NO SE PUDO ESCRIBIR ARCHIVO");
        }

        if (salida != null)
            salida.close();
    }
   
    

    
}
