/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grafosproject;
import grafosproject.Grafo;
/**
 *
 * @author Tania
 */
public class GrafosProject {

    public static void main(String[] args) {
    
       /*Generación de Babarasi*/
        Grafo d1 = new Grafo(30);//numero de nodos
        d1.modeloBA(4); //parámetro 'd' del modelo
        d1.writeDoc("Salidas\\GrafoBA_30.gv");
        
        Grafo d2 = new Grafo(100);//numero de nodos
        d2.modeloBA(15); //parámetro 'd' del modelo
        d2.writeDoc("Salidas\\GrafoBA_100.gv");
        
        Grafo d3 = new Grafo(500);//numero de nodos
        d3.modeloBA(75); //parámetro 'd' del modelo
        d3.writeDoc("Salidas\\GrafoBA_500.gv");
        
        
        /*Generacion de ER */
      
        Grafo a1 = new Grafo(30);//numero de nodos
        a1.modeloER(250); //número de aristas
        a1.writeDoc("Salidas\\GrafoER_30.gv");
        
        Grafo a2 = new Grafo(100);//numero de nodos
        a2.modeloER(834); //número de aristas
        a2.writeDoc("Salidas\\GrafoER_100.gv");
        
        Grafo a3 = new Grafo(500);//numero de nodos
        a3.modeloER(4167); //número de aristas
        a3.writeDoc("Salidas\\GrafoER_500.gv");
        
        
        /*Generacion de Gilbert*/
        
        Grafo c1 = new Grafo(30);//numero de nodos
        c1.modeloGilbert(0.015); //número de aristas
        c1.writeDoc("Salidas\\GrafoGilbert_30.gv");
        
        
        Grafo c2 = new Grafo(100);//numero de nodos
        c2.modeloGilbert(0.05); //número de aristas
        c2.writeDoc("Salidas\\GrafoGilbert_100.gv");
        
        Grafo c3 = new Grafo(500);//numero de nodos
        c3.modeloGilbert(0.25); //número de aristas
        c3.writeDoc("Salidas\\GrafoGilbert_500.gv");
        
        /*Geometrico*/
        
        Grafo e1 = new Grafo(30, "geograficosimple");//numero de nodos
        e1.modeloGeoSimple(0.3); //distancia a la que se deben conectar nodos
        e1.writeDoc("Salidas\\GrafoGeometrico_30.gv");
        
       
        Grafo e2 = new Grafo(100, "geograficosimple");//numero de nodos
        e2.modeloGeoSimple(.3); //distancia a la que se deben conectar nodos
        e2.writeDoc("Salidas\\GrafoGeometrico_100.gv");

        Grafo e3 = new Grafo(300, "geograficosimple");//numero de nodos
        e3.modeloGeoSimple(.3); //distancia a la que se deben conectar nodos
        e3.writeDoc("Salidas\\GrafoGeometrico_500.gv");
        
        
    
    }
}
